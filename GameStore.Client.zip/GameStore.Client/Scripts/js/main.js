﻿const
    CARD_ZOOM_VALUE = '105%',
    CARD_DEFAULT_VALUE = '100%'

    ;


//-----------------Events----------------------
document.body.onload = window.onresize = scaleCards;
//document.querySelector('.search_field').onmouseenter = () => { document.querySelector('#search-field').classList.remove('sf_collapse'); }
//document.querySelector('.search_field').onmouseleave = document.querySelector('#search-field').onblur = () => {
//    if (document.activeElement.id != document.querySelector('#search-field').id)
//        document.querySelector('#search-field').classList.add('sf_collapse');
//}
//    document.querySelector('#search-field').onblur = () => {
//    if (!document.querySelector('#search-field').hasFocus())
//        document.querySelector('#search-field').classList.add('sf_collapse');
//}


var cardImages = document.querySelectorAll('.card-img-top');




//Cards initialising (scale and zoom) 

for (let item of cardImages) {
    let imageSrc = item.style
        .backgroundImage;
    let image = document.createElement('img');
    image.src = imageSrc;
    if (image.width >= image.height) {
        item.style.backgroundSize = 'auto 100%';
    }
    else {
        item.style.backgroundSize = '100% auto';
    }
    item.onmouseenter = () => {
        item.style.backgroundSize = item.style.backgroundSize.replace(CARD_DEFAULT_VALUE, CARD_ZOOM_VALUE);
    }
    item.onmouseleave = () => {
        item.style.backgroundSize = item.style.backgroundSize.replace(CARD_ZOOM_VALUE, CARD_DEFAULT_VALUE);
    }
}

function scaleCards() {
    for (let item of cardImages) {
        item.style.height = item.offsetWidth * 1.4 + 'px';
    }
}

//-------