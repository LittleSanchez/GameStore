﻿using AutoMapper;
using GameStore.Client.Models;
using GameStore.DAL.Entities;
using GameStore.DLL.Services.Abstraction;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace GameStore.Client.Controllers
{
    public class GamesController : Controller
    {
        private readonly IGameService gameService;
        private readonly IMapper mapper;

        //DI #3
        public GamesController(IGameService _gameService, IMapper _mapper)
        {
            gameService = _gameService;
            mapper = _mapper;
        }
        // GET: Games
        public ActionResult Index()
        {
            var games = gameService.GetAllGames();

            //var model = new List<GameViewModel>();

            //foreach (var item in games)
            //{
            //    model.Add(new GameViewModel
            //    {
            //        Id = item.Id,
            //        Name = item.Name,
            //        Price = item.Price,
            //        Year = item.Year,
            //        Description = item.Description,
            //        Image = item.Image,
            //        Genre = item.Genre.Name,
            //        Developer = item.Developer.Name
            //    });
            //}
            var model = mapper.Map<ICollection<GameViewModel>>(games);

            return View(model);
        }
        [HttpGet]
        public ActionResult Create()
        {
            ViewBag.Developers = gameService.GetDevelopers();
            return View();
        }
        [HttpPost]
        public ActionResult Create(GameViewModel model)
        {
            if (ModelState.IsValid)
            {

                //var game = new Game
                //{
                //    Id = model.Id,
                //    Name = model.Name,
                //    Price = model.Price,
                //    Year = model.Year,
                //    Description = model.Description,
                //    Image = model.Image,
                //    Developer = new Developer { Name = model.Developer },
                //    Genre = new Genre { Name = model.Genre }
                //};

                var game = mapper.Map<Game>(model);

                gameService.AddGame(game);

                return RedirectToAction("Index");
            }
            else return Create();
        }
        [HttpGet]
        public ActionResult Edit(int id)
        {
            var model = gameService.GetAllGames().FirstOrDefault(x => x.Id == id);
            var game = mapper.Map<GameViewModel>(model);
            return View(game);
        }
        [HttpPost]
        public ActionResult Edit(GameViewModel model)
        {
            if (ModelState.IsValid)
            {
                var game = mapper.Map<Game>(model);
                gameService.UpdateGame(game);
                return RedirectToAction("Index");
            }
            return View(model.Id);
        }
    }
}